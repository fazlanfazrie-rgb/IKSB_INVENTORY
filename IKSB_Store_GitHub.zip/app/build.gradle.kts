plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iksb.inventory"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.iksb.inventory"
        minSdk = 24
        targetSdk = 34
    }
}
