IKSB Store - Auto-build GitHub project
Follow README to upload and run actions.
